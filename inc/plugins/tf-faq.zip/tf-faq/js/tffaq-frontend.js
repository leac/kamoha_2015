jQuery(document).ready(function($) {
    $("#tffaq-tabs").tabs({cookie: {}}).show();
	
    /* (Lea - 2014/06) - changed for p to div, explenation in tf-faq.php*/
    $('div.tffaq-question a').click(function() {
        var tfaid = $(this).data("options").id;
        $('#tffaq-answer-' + tfaid).slideToggle();
        $('#tffaq-tabs-2 #tffaq-answer-' + tfaid).slideToggle();

    });
    
    // Track clicking the search button on the Ask Rabbi page using jQuery Event API v1.3
    $('#tffaq-search-btn').on('click', function() {
      ga('send', 'event', 'Search', 'click',$(this).attr('value'));
    });

});